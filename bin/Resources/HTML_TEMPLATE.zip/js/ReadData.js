var config = {
    apiKey: "AIzaSyCDrPABzn5ZTpv8LThZtWCM91u7AQMFV_E",
    authDomain: "formbuilder-67b5e.firebaseapp.com",
    databaseURL: "https://formbuilder-67b5e.firebaseio.com",
    projectId: "formbuilder-67b5e",
    storageBucket: "formbuilder-67b5e.appspot.com",
    messagingSenderId: "526672014312"
};
firebase.initializeApp(config);


var head = document.getElementById('head');
var content = document.getElementById('tableContent');


var userDataRef = firebase.database().ref("Messages");
console.log(firebase.database());
var ref = firebase.database().ref("Messages");

var keys = [];
var tableData = [];
var columns = [];


userDataRef.on('value', function (snapshot) {

    keys = [];
    console.log(snapshot.exists());
    if (snapshot.exists()) {

        document.getElementById('Alert').style.display = "none";


        content.innerHTML = "";


        var index = 1;

        snapshot.forEach(function (childSnapshot) {
            var key = childSnapshot.key;
            keys.push(key);
            var childData = childSnapshot.val();

            var row = [];
            row.push(index);
            columns = [];
            columns.push({ title: 'ID' });

            var tr = document.createElement("TR");

            var idTd = document.createElement("TD");
            idTd.innerText = index.toString();

            tr.appendChild(idTd);

            for (var key in childData) {

                columns.push({ title: key });
                row.push(childData[key]);

            }
            index++;
            tableData.push(row);
     


        });




    }else{
        document.getElementById('Form').style.display = "none";

        document.getElementById('Alert').style.display = "";
    }


    dataTable = $('#dataTable').DataTable({
        data: tableData,
        columns: columns
    });
});


