
firebase.initializeApp(firebaseConfig);

// Reference messages
var msgRef = firebase.database().ref('Messages');


document.getElementById('Form').addEventListener('submit', submitForm);

function submitForm(e) {

    e.preventDefault();

    var allInputs = document.getElementById('Form').getElementsByTagName('Input');
    var allSelectInputs = document.getElementById('Form').getElementsByTagName('select');


    var data = {};

    for (var i = 0; i < allInputs.length; i++) {
        data[allInputs[i].getAttribute('name')] = allInputs[i].value;
    }

    for (var i = 0; i < allSelectInputs.length; i++) {
        data[allSelectInputs[i].getAttribute('name')] = allSelectInputs[i].value;
    }


    console.log(data);


    saveMsg(data);
/*
    document.querySelector('.Alert').style.color = 'white';
    document.querySelector('.Alert').style.background = '#79c879';

    setTimeout(() => {

        document.querySelector('.Alert').style.animation = 'fade  2s 1';
        document.querySelector('.Alert').style.color = 'transparent';
        document.querySelector('.Alert').style.background = 'transparent';

    }, 2000);
*/
    document.getElementById('Form').reset();

}

function getInputValue(id) {
    return document.getElementById(id).value;
}


function saveMsg(data) {

    var newMsgRef = msgRef.push();

    newMsgRef.set(data);

}

